const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PDFDocument = require('pdfkit');
const { config } = require('../config/env');
const Product = require('../models/Product');

// Brand palette, shared with the invoice.
const GREEN = '#0F3D1E';
const GREEN_MID = '#1B7A3E';
const GOLD = '#DAA520';
const INK = '#1A1A1A';
const GREY = '#555555';
const RULE = '#E2E2E2';

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const M = 32;
const CONTENT_W = PAGE_W - M * 2;
const FOOTER_H = 46;
const BOTTOM_LIMIT = PAGE_H - FOOTER_H - 10;

// Two columns of product cards — halves the page count versus one.
const GUTTER = 14;
const COL_W = (CONTENT_W - GUTTER) / 2;
const THUMB = 34;
const CARD_H = 46;

const THUMB_PX = 150; // rendered thumbnail width, in pixels
const THUMB_QUALITY = 74;

const rs = (n) => `Rs. ${Number(n || 0).toFixed(2)}`;

/** Same character folding the invoice uses — standard PDF fonts are Latin-1. */
function pdfSafe(value) {
  if (value === undefined || value === null) return '';
  return String(value)
    .replace(/[‘’‛]/g, "'")
    .replace(/[“”„]/g, '"')
    .replace(/[–—]/g, '-')
    .replace(/…/g, '...')
    .replace(/½/g, ' 1/2')
    .replace(/¼/g, ' 1/4')
    .replace(/¾/g, ' 3/4')
    .replace(/₹/g, 'Rs.')
    .replace(/[•·]/g, '-')
    .replace(/[^\n\t\x20-\x7E\xA0-\xFF]/g, '')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

// ─────────────────────────────────────────────────────────────
//  Thumbnails
// ─────────────────────────────────────────────────────────────

let jimpModule;
function getJimp() {
  if (jimpModule !== undefined) return jimpModule;
  try {
    // eslint-disable-next-line global-require
    jimpModule = require('jimp');
  } catch {
    // eslint-disable-next-line no-console
    console.warn(
      '  jimp is not installed — the price list will be built without product images.\n' +
        '   Run `npm install jimp` in the Backend folder to include them.'
    );
    jimpModule = null;
  }
  return jimpModule;
}

const thumbCacheDir = () => path.join(config.cacheDir, 'thumbs');

/** Maps a stored image path like "/images/foo.png" onto a real file. */
function resolveImagePath(image) {
  if (!image || /^https?:\/\//i.test(image)) return null; // remote images are skipped
  const rel = image.replace(/^\/+/, '');
  const full = path.join(config.productImagesDir, rel);
  // Never let a stored path escape the images folder.
  if (!full.startsWith(path.resolve(config.productImagesDir))) return null;
  return fs.existsSync(full) ? full : null;
}

/**
 * Returns a small JPEG buffer for a product image, cached on disk.
 *
 * The originals are several hundred KB each; embedding them directly
 * would produce a PDF far too large to send over WhatsApp. Each one is
 * resized once and reused.
 */
async function getThumbnail(image) {
  const source = resolveImagePath(image);
  if (!source) return null;

  const Jimp = getJimp();
  if (!Jimp) return null;

  let stat;
  try {
    stat = await fs.promises.stat(source);
  } catch {
    return null;
  }

  const key = crypto
    .createHash('sha1')
    .update(`${source}:${stat.mtimeMs}:${stat.size}:${THUMB_PX}:${THUMB_QUALITY}`)
    .digest('hex');
  const cached = path.join(thumbCacheDir(), `${key}.jpg`);

  try {
    return await fs.promises.readFile(cached);
  } catch {
    /* not cached yet */
  }

  try {
    const JimpCtor = Jimp.Jimp || Jimp;
    const img = await JimpCtor.read(source);
    if (img.bitmap.width > THUMB_PX) img.resize({ w: THUMB_PX });
    const buffer = await img.getBuffer('image/jpeg', { quality: THUMB_QUALITY });

    await fs.promises.mkdir(thumbCacheDir(), { recursive: true });
    await fs.promises.writeFile(cached, buffer);
    return buffer;
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn(`  Could not process image ${image}: ${err.message}`);
    return null;
  }
}

/** Resizes several images at once, but not so many that memory spikes. */
async function buildThumbnails(products, concurrency = 5) {
  const byImage = new Map();
  const queue = [...new Set(products.map((p) => p.image).filter(Boolean))];
  let cursor = 0;

  const worker = async () => {
    while (cursor < queue.length) {
      const image = queue[cursor];
      cursor += 1;
      // eslint-disable-next-line no-await-in-loop
      const buf = await getThumbnail(image);
      if (buf) byImage.set(image, buf);
    }
  };

  await Promise.all(Array.from({ length: Math.min(concurrency, queue.length) }, worker));
  return byImage;
}

// ─────────────────────────────────────────────────────────────
//  Page furniture
// ─────────────────────────────────────────────────────────────

function withoutPageBreaks(doc, fn) {
  const saved = doc.page.margins.bottom;
  doc.page.margins.bottom = 0;
  try {
    fn();
  } finally {
    doc.page.margins.bottom = saved;
  }
}

let cachedLogo = null;
function getLogo() {
  if (cachedLogo !== null) return cachedLogo;
  for (const p of [path.join(config.assetsDir, 'logo.png'), path.join(config.assetsDir, 'MVP.png')]) {
    try {
      if (fs.existsSync(p)) {
        cachedLogo = fs.readFileSync(p);
        return cachedLogo;
      }
    } catch {
      /* fall through */
    }
  }
  cachedLogo = false;
  return cachedLogo;
}

function drawFooter(doc, pageNumber, totalPages) {
  withoutPageBreaks(doc, () => {
    const top = PAGE_H - FOOTER_H;
    doc.save();
    doc.rect(M, top, CONTENT_W, 30).fill(GREEN);
    doc
      .fillColor(GOLD)
      .font('Helvetica-Bold')
      .fontSize(8.5)
      .text(
        `${pdfSafe(config.business.name)}  |  ${pdfSafe(config.business.phone)}  |  Order on WhatsApp`,
        M,
        top + 7,
        { width: CONTENT_W, align: 'center', lineBreak: false }
      );
    doc
      .fillColor('#FFFFFF')
      .font('Helvetica')
      .fontSize(7)
      .text(pdfSafe(config.business.website), M, top + 19, {
        width: CONTENT_W,
        align: 'center',
        lineBreak: false,
      });
    doc
      .fillColor(GREY)
      .fontSize(7)
      .text(`Page ${pageNumber} of ${totalPages}`, M, top - 9, {
        width: CONTENT_W,
        align: 'right',
        lineBreak: false,
      });
    doc.restore();
  });
}

/** Masthead for page 1. Returns the y to continue from. */
function drawHeader(doc, meta) {
  let y = M;
  const logo = getLogo();

  if (logo) {
    try {
      doc.image(logo, M, y, { height: 30 });
    } catch {
      doc.font('Helvetica-Bold').fontSize(18).fillColor(GREEN).text(pdfSafe(config.business.name), M, y + 6);
    }
  } else {
    doc.font('Helvetica-Bold').fontSize(18).fillColor(GREEN).text(pdfSafe(config.business.name), M, y + 6);
  }

  doc
    .font('Helvetica')
    .fontSize(8)
    .fillColor(GREY)
    .text(
      `${pdfSafe(config.business.phone)}  |  ${pdfSafe(config.business.email)}`,
      PAGE_W / 2,
      y + 4,
      { width: CONTENT_W / 2, align: 'right' }
    )
    .fillColor(GREEN_MID)
    .text(pdfSafe(config.business.website), PAGE_W / 2, y + 15, {
      width: CONTENT_W / 2,
      align: 'right',
    });

  y += 36;

  doc.rect(M, y, CONTENT_W, 26).fill(GREEN);
  doc
    .fillColor('#FFFFFF')
    .font('Helvetica-Bold')
    .fontSize(13)
    .text('PRICE LIST', M + 12, y + 7.5, { lineBreak: false, characterSpacing: 2 });
  doc
    .fillColor(GOLD)
    .font('Helvetica')
    .fontSize(8)
    .text(
      `${meta.productCount} items  ·  updated ${meta.date}`,
      M,
      y + 9.5,
      { width: CONTENT_W - 12, align: 'right', lineBreak: false }
    );

  y += 32;

  doc
    .font('Helvetica')
    .fontSize(7.5)
    .fillColor(GREY)
    .text(pdfSafe(config.business.tagline), M, y, { width: CONTENT_W, lineBreak: false });

  return y + 14;
}

function drawContinuationHeader(doc) {
  const y = M;
  doc
    .font('Helvetica-Bold')
    .fontSize(10)
    .fillColor(GREEN)
    .text(`${pdfSafe(config.business.name)} — Price List`, M, y, { lineBreak: false });
  doc
    .save()
    .lineWidth(1)
    .strokeColor(GREEN)
    .moveTo(M, y + 14)
    .lineTo(PAGE_W - M, y + 14)
    .stroke()
    .restore();
  return y + 24;
}

function drawCategoryBand(doc, y, title, count) {
  const h = 18;
  doc.save().rect(M, y, CONTENT_W, h).fill(GOLD).restore();
  doc
    .font('Helvetica-Bold')
    .fontSize(9)
    .fillColor(GREEN)
    .text(pdfSafe(title).toUpperCase(), M + 8, y + 5, { lineBreak: false });
  doc
    .font('Helvetica')
    .fontSize(8)
    .fillColor(GREEN)
    .text(`${count} item${count === 1 ? '' : 's'}`, M, y + 5.5, {
      width: CONTENT_W - 8,
      align: 'right',
      lineBreak: false,
    });
  return y + h + 6;
}

/** One product card: thumbnail, name, unit, price. */
function drawCard(doc, x, y, product, thumb) {
  doc.save();

  doc.lineWidth(0.5).strokeColor(RULE).rect(x, y, COL_W, CARD_H).stroke();

  // thumbnail
  const imgX = x + 5;
  const imgY = y + (CARD_H - THUMB) / 2;
  if (thumb) {
    try {
      doc.image(thumb, imgX, imgY, { fit: [THUMB, THUMB], align: 'center', valign: 'center' });
    } catch {
      /* an unreadable image just leaves the slot empty */
    }
  } else {
    doc.rect(imgX, imgY, THUMB, THUMB).fill('#F3F4F3');
  }

  const textX = imgX + THUMB + 7;
  const priceW = 62;
  const textW = COL_W - (textX - x) - priceW - 8;

  doc
    .font('Helvetica-Bold')
    .fontSize(7.5)
    .fillColor(GREEN)
    .text(pdfSafe(product.name), textX, y + 9, { width: textW, height: 20, ellipsis: true });

  doc
    .font('Helvetica')
    .fontSize(6.5)
    .fillColor(GREY)
    .text(pdfSafe(product.content), textX, y + CARD_H - 16, { width: textW, lineBreak: false });

  // price, right-aligned
  const priceX = x + COL_W - priceW - 6;
  const hasOffer =
    product.offerPrice !== null && product.offerPrice !== undefined && product.offerPrice < product.price;

  if (hasOffer) {
    doc
      .font('Helvetica-Bold')
      .fontSize(9)
      .fillColor(GREEN_MID)
      .text(rs(product.offerPrice), priceX, y + 11, { width: priceW, align: 'right', lineBreak: false });
    const struck = rs(product.price);
    doc.font('Helvetica').fontSize(6.5).fillColor(GREY);
    doc.text(struck, priceX, y + 25, { width: priceW, align: 'right', lineBreak: false });
    const w = doc.widthOfString(struck);
    doc
      .lineWidth(0.4)
      .strokeColor(GREY)
      .moveTo(priceX + priceW - w, y + 28)
      .lineTo(priceX + priceW, y + 28)
      .stroke();
  } else {
    doc
      .font('Helvetica-Bold')
      .fontSize(9.5)
      .fillColor(INK)
      .text(rs(product.price), priceX, y + 17, { width: priceW, align: 'right', lineBreak: false });
  }

  doc.restore();
}

// ─────────────────────────────────────────────────────────────
//  Build
// ─────────────────────────────────────────────────────────────

/** Loads every product a customer is allowed to see, in shop order. */
async function loadActiveProducts() {
  return Product.find({ isActive: true }).sort({ categoryOrder: 1, sortOrder: 1, productId: 1 });
}

/**
 * Fingerprint of everything that can change the PDF. Used as the cache
 * key, so a price edit invalidates it instantly but repeat downloads of
 * an unchanged list are free.
 */
function catalogueFingerprint(products) {
  const h = crypto.createHash('sha1');
  h.update(config.business.name + config.business.phone + config.business.website);
  for (const p of products) {
    h.update(
      `${p.productId}|${p.name}|${p.price}|${p.offerPrice ?? ''}|${p.content}|${p.image}|${p.categoryTitle}|${p.isAvailable}`
    );
  }
  return h.digest('hex').slice(0, 16);
}

async function renderPdf(products, thumbs) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: M, bottom: M, left: M, right: M },
      bufferPages: true,
      info: {
        Title: `${config.business.name} Price List`,
        Author: config.business.name,
        Subject: 'Price List',
      },
    });

    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const meta = {
      productCount: products.length,
      date: new Date().toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
    };

    let y = drawHeader(doc, meta);

    // Group in shop order
    const groups = [];
    for (const p of products) {
      const last = groups[groups.length - 1];
      if (last && last.title === p.categoryTitle) last.items.push(p);
      else groups.push({ title: p.categoryTitle, items: [p] });
    }

    const newPage = () => {
      doc.addPage();
      return drawContinuationHeader(doc);
    };

    for (const group of groups) {
      // Keep a band with at least one row of cards under it.
      if (y + 18 + 6 + CARD_H > BOTTOM_LIMIT) y = newPage();
      y = drawCategoryBand(doc, y, group.title, group.items.length);

      for (let i = 0; i < group.items.length; i += 2) {
        if (y + CARD_H > BOTTOM_LIMIT) {
          y = newPage();
          y = drawCategoryBand(doc, y, `${group.title} (contd.)`, group.items.length - i);
        }

        const left = group.items[i];
        const right = group.items[i + 1];

        drawCard(doc, M, y, left, thumbs.get(left.image));
        if (right) drawCard(doc, M + COL_W + GUTTER, y, right, thumbs.get(right.image));

        y += CARD_H + 6;
      }

      y += 4;
    }

    // Closing note
    if (y + 46 > BOTTOM_LIMIT) y = newPage();
    doc.save();
    doc.rect(M, y, CONTENT_W, 38).fill('#FFFAEB');
    doc.rect(M, y, 3, 38).fill(GOLD);
    doc
      .font('Helvetica-Bold')
      .fontSize(8.5)
      .fillColor(GREEN)
      .text('To place an order', M + 12, y + 8, { lineBreak: false });
    doc
      .font('Helvetica')
      .fontSize(7.5)
      .fillColor(GREY)
      .text(
        `Visit ${pdfSafe(config.business.website)} or message us on WhatsApp at ${pdfSafe(
          config.business.phone
        )}. Prices are inclusive of applicable discounts shown above and are subject to change.`,
        M + 12,
        y + 20,
        { width: CONTENT_W - 24 }
      );
    doc.restore();

    const range = doc.bufferedPageRange();
    for (let i = 0; i < range.count; i += 1) {
      doc.switchToPage(range.start + i);
      drawFooter(doc, i + 1, range.count);
    }

    doc.flushPages();
    doc.end();
  });
}

/**
 * Returns the current price-list PDF, building it only when the
 * catalogue has actually changed since the last build.
 */
async function getPriceListPdf({ force = false } = {}) {
  const products = await loadActiveProducts();

  if (!products.length) {
    const err = new Error('There are no products to list yet.');
    err.statusCode = 404;
    throw err;
  }

  const fingerprint = catalogueFingerprint(products);
  const cachePath = path.join(config.cacheDir, `price-list-${fingerprint}.pdf`);

  if (!force) {
    try {
      const buffer = await fs.promises.readFile(cachePath);
      return { buffer, fingerprint, cached: true, productCount: products.length };
    } catch {
      /* not built yet */
    }
  }

  const thumbs = await buildThumbnails(products);
  const buffer = await renderPdf(products, thumbs);

  try {
    await fs.promises.mkdir(config.cacheDir, { recursive: true });
    await fs.promises.writeFile(cachePath, buffer);
    // Drop stale builds so the folder does not grow forever.
    const files = await fs.promises.readdir(config.cacheDir);
    await Promise.all(
      files
        .filter((f) => f.startsWith('price-list-') && f !== path.basename(cachePath))
        .map((f) => fs.promises.unlink(path.join(config.cacheDir, f)).catch(() => {}))
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.warn('Could not cache the price list:', err.message);
  }

  return { buffer, fingerprint, cached: false, productCount: products.length };
}

function priceListFileName() {
  const stamp = new Date().toISOString().slice(0, 10);
  const name = config.business.name.replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '');
  return `${name}-Price-List-${stamp}.pdf`;
}

module.exports = { getPriceListPdf, priceListFileName, pdfSafe };
