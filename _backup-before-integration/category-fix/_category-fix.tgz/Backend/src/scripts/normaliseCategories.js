/**
 * Merges categories that share a name but drifted onto different ids.
 *
 *   npm run fix:categories
 *
 * A category's id and its display name are independent ("sparklers" /
 * "SPARKLER ITEMS"). An older version of the edit endpoint re-derived
 * the id from the name whenever a product was saved, which quietly moved
 * that product into a second category with an identical heading — so the
 * shop showed "SPARKLER ITEMS" twice.
 *
 * This finds every group of products sharing a name, picks the id most
 * of them already use, and moves the strays back. It is safe to run any
 * number of times and changes nothing when there is nothing to fix.
 */
const mongoose = require('mongoose');
const Product = require('../models/Product');

/**
 * @param {{ silent?: boolean }} options
 * @returns {Promise<{ merged: number, moved: number, groups: Array }>}
 */
async function normaliseCategories({ silent = false } = {}) {
  const products = await Product.find().select('productId name categoryId categoryTitle categoryOrder');

  // Group by normalised name.
  const byName = new Map();
  for (const p of products) {
    const key = (p.categoryTitle || '').trim().toLowerCase();
    if (!key) continue;
    if (!byName.has(key)) byName.set(key, []);
    byName.get(key).push(p);
  }

  const report = [];
  let moved = 0;

  for (const [, group] of byName) {
    const ids = new Map();
    for (const p of group) {
      if (!ids.has(p.categoryId)) ids.set(p.categoryId, []);
      ids.get(p.categoryId).push(p);
    }
    if (ids.size < 2) continue; // this name is already consistent

    // The winner is the id most products use; ties go to the lowest
    // categoryOrder, which is the one that was there first.
    const ranked = [...ids.entries()].sort((a, b) => {
      if (b[1].length !== a[1].length) return b[1].length - a[1].length;
      return Math.min(...a[1].map((p) => p.categoryOrder)) - Math.min(...b[1].map((p) => p.categoryOrder));
    });

    const [winnerId, winnerProducts] = ranked[0];
    const winnerOrder = Math.min(...winnerProducts.map((p) => p.categoryOrder));
    const winnerTitle = winnerProducts[0].categoryTitle;

    const strays = ranked.slice(1).flatMap(([, list]) => list);

    for (const p of strays) {
      await Product.updateOne(
        { _id: p._id },
        { $set: { categoryId: winnerId, categoryTitle: winnerTitle, categoryOrder: winnerOrder } }
      );
      moved += 1;
    }

    report.push({
      title: winnerTitle,
      keptId: winnerId,
      mergedIds: ranked.slice(1).map(([id]) => id),
      productsMoved: strays.length,
      products: strays.map((p) => `#${p.productId} ${p.name}`),
    });
  }

  if (!silent && report.length) {
    console.log(`\n  Merged ${report.length} duplicated categor${report.length === 1 ? 'y' : 'ies'}:`);
    for (const r of report) {
      console.log(`\n   "${r.title}"`);
      console.log(`     kept   : ${r.keptId}`);
      console.log(`     merged : ${r.mergedIds.join(', ')}`);
      r.products.forEach((n) => console.log(`     moved  : ${n}`));
    }
    console.log('');
  }

  return { merged: report.length, moved, groups: report };
}

module.exports = { normaliseCategories };

// Run directly: `node src/scripts/normaliseCategories.js`
if (require.main === module) {
  /* eslint-disable global-require */
  const { validateConfig } = require('../config/env');
  const { connectDB, disconnectDB } = require('../config/db');
  /* eslint-enable global-require */

  (async () => {
    validateConfig();
    await connectDB();
    const result = await normaliseCategories();
    if (!result.merged) {
      console.log('\n  No duplicated categories — nothing to fix.\n');
    } else {
      console.log(`  ${result.moved} product(s) moved back into their original category.\n`);
    }
    await mongoose.connection.close();
    await disconnectDB();
  })().catch(async (err) => {
    console.error('\n  Failed:', err.message, '\n');
    process.exit(1);
  });
}
