const mongoose = require('mongoose');

/**
 * Product — the single source of truth for pricing.
 *
 * `productId` is the numeric id the existing frontend already uses
 * (data.js items 1..101). It is kept so the current cart, which is
 * keyed by that number, keeps working without any change.
 */
const productSchema = new mongoose.Schema(
  {
    productId: {
      type: Number,
      required: [true, 'productId is required'],
      unique: true,
      index: true,
      min: [1, 'productId must be a positive number'],
    },
    name: {
      type: String,
      required: [true, 'Product name is required'],
      trim: true,
      maxlength: 200,
    },
    tamilName: { type: String, trim: true, default: '', maxlength: 200 },
    description: { type: String, trim: true, default: '', maxlength: 1000 },

    // "1 BOX", "10 PKT", "1 PCS" — shown in the price list and on the invoice
    content: { type: String, trim: true, default: '1 BOX', maxlength: 50 },

    image: { type: String, trim: true, default: '/MVP.png' },

    categoryId: {
      type: String,
      required: [true, 'categoryId is required'],
      trim: true,
      index: true,
    },
    categoryTitle: {
      type: String,
      required: [true, 'categoryTitle is required'],
      trim: true,
    },
    categoryOrder: { type: Number, default: 0 },

    // The normal selling price (what the price list shows).
    price: {
      type: Number,
      required: [true, 'Price is required'],
      min: [0, 'Price cannot be negative'],
    },

    // Optional promotional price. When set (and below `price`), this is
    // what the customer actually pays per unit, and the difference is
    // recorded as the line discount. null => fall back to a percentage.
    offerPrice: {
      type: Number,
      default: null,
      min: [0, 'Offer price cannot be negative'],
    },

    // Per-product override. null => order-level DISCOUNT_PERCENT applies.
    // Ignored when `offerPrice` is set.
    discountPercent: {
      type: Number,
      default: null,
      min: [0, 'Discount cannot be negative'],
      max: [100, 'Discount cannot exceed 100%'],
    },
    // Per-product override. null => order-level TAX_PERCENT applies.
    taxPercent: {
      type: Number,
      default: null,
      min: [0, 'Tax cannot be negative'],
      max: [100, 'Tax cannot exceed 100%'],
    },

    stock: {
      type: Number,
      default: 1000,
      min: [0, 'Stock cannot be negative'],
    },
    // When true, stock is not decremented and never blocks an order.
    trackStock: { type: Boolean, default: true },

    isAvailable: { type: Boolean, default: true, index: true },
    isActive: { type: Boolean, default: true, index: true },

    sortOrder: { type: Number, default: 0 },

    // Every price change is recorded, so you can always answer
    // "what did this cost last week, and who changed it?".
    priceHistory: {
      type: [
        {
          _id: false,
          price: Number,
          offerPrice: { type: Number, default: null },
          previousPrice: Number,
          previousOfferPrice: { type: Number, default: null },
          changedBy: { type: String, default: 'admin' },
          note: { type: String, default: '' },
          at: { type: Date, default: Date.now },
        },
      ],
      default: [],
    },

    createdBy: { type: String, default: '' },
    updatedBy: { type: String, default: '' },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

productSchema.index({ categoryOrder: 1, sortOrder: 1 });
productSchema.index({ name: 'text' });

/**
 * What one unit actually costs today: the offer price when it is set and
 * genuinely cheaper, otherwise the normal price.
 */
productSchema.virtual('effectivePrice').get(function effectivePrice() {
  if (this.offerPrice !== null && this.offerPrice !== undefined && this.offerPrice < this.price) {
    return this.offerPrice;
  }
  return this.price;
});

/** True when a promotional price is currently in force. */
productSchema.virtual('hasOffer').get(function hasOffer() {
  return (
    this.offerPrice !== null && this.offerPrice !== undefined && this.offerPrice < this.price
  );
});

/** Records a price change on the audit trail. Does not save. */
productSchema.methods.recordPriceChange = function recordPriceChange(
  previousPrice,
  previousOfferPrice,
  changedBy,
  note
) {
  this.priceHistory.push({
    price: this.price,
    offerPrice: this.offerPrice ?? null,
    previousPrice,
    previousOfferPrice: previousOfferPrice ?? null,
    changedBy: changedBy || 'admin',
    note: note || '',
    at: new Date(),
  });
  // Keep the trail useful without letting it grow without bound.
  if (this.priceHistory.length > 50) {
    this.priceHistory = this.priceHistory.slice(-50);
  }
};

/** Whether this product can currently be ordered in the requested quantity. */
productSchema.methods.canFulfil = function canFulfil(qty) {
  if (!this.isActive || !this.isAvailable) return false;
  if (!this.trackStock) return true;
  return this.stock >= qty;
};

/**
 * Shape sent to the frontend. Deliberately mirrors the old data.js item
 * shape ({ id, name, content, price }) so existing components keep working.
 */
productSchema.methods.toPublicJSON = function toPublicJSON() {
  return {
    id: this.productId,
    _id: this._id,
    productId: this.productId,
    name: this.name,
    tamilName: this.tamilName,
    description: this.description,
    content: this.content,
    image: this.image,
    categoryId: this.categoryId,
    categoryTitle: this.categoryTitle,
    price: this.price,
    offerPrice: this.hasOffer ? this.offerPrice : null,
    effectivePrice: this.effectivePrice,
    hasOffer: this.hasOffer,
    discountPercent: this.discountPercent,
    taxPercent: this.taxPercent,
    stock: this.trackStock ? this.stock : null,
    trackStock: this.trackStock,
    isAvailable: this.isAvailable && this.isActive,
  };
};

/**
 * Everything an admin needs, including fields hidden from customers
 * (inactive flag, raw stock, audit trail).
 */
productSchema.methods.toAdminJSON = function toAdminJSON() {
  return {
    id: this.productId,
    _id: this._id,
    productId: this.productId,
    name: this.name,
    tamilName: this.tamilName,
    description: this.description,
    content: this.content,
    image: this.image,
    categoryId: this.categoryId,
    categoryTitle: this.categoryTitle,
    categoryOrder: this.categoryOrder,
    sortOrder: this.sortOrder,
    price: this.price,
    offerPrice: this.offerPrice,
    effectivePrice: this.effectivePrice,
    hasOffer: this.hasOffer,
    discountPercent: this.discountPercent,
    taxPercent: this.taxPercent,
    stock: this.stock,
    trackStock: this.trackStock,
    isAvailable: this.isAvailable,
    isActive: this.isActive,
    priceHistory: (this.priceHistory || []).slice(-10).reverse(),
    createdBy: this.createdBy,
    updatedBy: this.updatedBy,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model('Product', productSchema);
